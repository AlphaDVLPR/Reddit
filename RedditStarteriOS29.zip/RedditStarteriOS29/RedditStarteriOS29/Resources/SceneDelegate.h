//
//  SceneDelegate.h
//  RedditStarteriOS29
//
//  Created by Darin Armstrong on 10/9/19.
//  Copyright © 2019 Darin Armstrong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

